"use strict";

var vp_width = window.innerWidth/2; //create and assign a variable variable to hold the screen size
var vp_height = window.innerHeight/2;

var x = vp_width/2; //create and assign a variable to hold an position that is half of the viewport
var y = vp_height/2;

var x2 = 100
var y2 = 100

var rectWidth =20;
var rectHeight=20;
var rectHeight2=20;
var rectWidth2=20;

var colour = "ff0000";


function set_vp() {
	vp_width = window.innerWidth/2;
	vp_height = window.innerHeight/2;

	x = vp_width/2; //update the ball's initial position
	y = vp_height/2;

	resizeCanvas(vp_width, vp_height); //call the P5 resize canvas function; is this abstraction?
}

function up(){
    y = y - 5;
}

function down(){
    y = y + 5;
}

function left(){
    x = x - 5;
}

function right(){
    x = x + 5;
}


function preload() {
	//p5 defined function
}

function setup() {
	//this p5 defined function runs automatically once the preload function is done
	
	var viewport = createCanvas(vp_width, vp_height);
    viewport.parent("viewport_container"); //move the canvas so it’s inside the target div

    frameRate(50);
}

function paint_background() {
	//this function fills the canvas background with the specific colour
	background("#abb5b9");
}

function paint_player() {
	fill("#" + colour); //set a fill colour using the variable
	rect(x, y, rectWidth,rectHeight); //draw a circle and x, y with a diameter of 20
  fill(0)
  rect(x2,y2,rectWidth2,rectHeight2)

}

function square_col_detection(){
  if (x + rectWidth > x2 && y + rectHeight > y2 + rectHeight2 && x < x2 + rectWidth2 && x + rectWidth > x2 - rectWidth2) {
    console.log("BOOM")
  }
}


function draw() {
	 //this p5 defined function runs every refresh cycle
	 paint_background();
	 paint_player();
  square_col_detection();
}



//create events for the number buttons
var buttons = document.getElementsByTagName('button');
for(let i = 0; i < buttons.length; i++) { //loop through each specific instance of number buttons
	buttons[i].addEventListener('click', function() {
        
        switch(this.id) {
            case "up": up(); break;
            case "down": down(); break;
            case "left": left(); break;
            case "right": right(); break;
        }

	})
}

window.addEventListener('resize', set_vp);
